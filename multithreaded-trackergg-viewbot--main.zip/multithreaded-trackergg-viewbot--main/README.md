<a name="readme-top"></a>

<!-- PROJECT LOGO -->
# Multithreaded Tracker.GG Viewbot

**PROJECT PATCHED AS OF 2024-10-15, WORKING ON NEW BYPASSES**  

Kindly ⭐ the project to show your support. Your interest motivates further updates!

---

### What is being worked on?:
* Further spoofing to fix the "patch" put in place by tracker.gg. Ps, nice cf_clearence cookie.”
* Async support as the project will be significantly slower and heavier to run as I'm adding a lot of QOL features as well as advanced session spoofing expect 50-100 sessions/ minute.
* Advanced logging system, usage statistics, easier request debugging, dynamic header spoofing.

This project serves as a **base** but is easy to modify to your needs.

## About the Project

This is the final release of the project. Unfortunately, earlier versions have been ripped off and sold as "viewbotting as a service" (for $5/1000 views). Ridiculous, given that with $2-3 worth of datacenter proxies, you can generate 500k views in a day.

At this point, it doesn’t matter if this gets ripped and resold again—skidders will be skidders. The rest of you, **ENJOY**!

> **Note:** I will not be responding to basic questions like:  
> - "Where do I put the proxies?"  
> - "Why does it not load?"  
> - "How do I run it?"  
> 
> Use **ChatGPT** or **Google** for simple inquiries. If you struggle to get it running, I can assist on a VPS for a $10 fee to avoid spamming my inbox.

### Why even make this project?:
* Affordable and easy way to make your tracker profile appear more “legit.”
* High demand project, first publicly available solution.
* Gamerdoc promised me an EV certificate.

This project serves as a **base** but is easy to modify to your needs.

<p align="right">(<a href="#readme-top">back to top</a>)</p>

---

## Getting Started

### Installation

To set up the project, follow these simple steps:

1. **Clone the repository:**
   ```bash
   git clone https://github.com/Zaptons/multithreaded-trackergg-viewbot-.git
Install requirements:

   ```python
   pip install -r requirements.txt
```

Edit the config file: Update the configuration details to match your setup.

Add Proxies: I recommend rotating datacenter proxies as they are cost-effective and perform well.
You can use proxies from Kocerroxy.
For $2/day, you can run 250 threads of rotating proxies, enough for 500k views if running continuously for 24 hours.
https://app.kocerroxy.com/register?referral=638537bff2ab58cdfde39807
<p align="right">(<a href="#readme-top">back to top</a>)</p>
License
This project is distributed under the MIT License. For more details, see the LICENSE.txt file.

<p align="right">(<a href="#readme-top">back to top</a>)</p>
Contacts
Discord: Zaptons
Email: contact@zaptons.com / releaselua@proton.me
<p align="right">(<a href="#readme-top">back to top</a>)</p>
Support
If you'd like to support this project, you can buy me a coffee! Your donations are appreciated, though not required.

### LTC: MLLQFPHEPimNKefuqRakU1Y2MEDo3fE89J
### USDC (Base): 0xF6751c85357980Bd6598148600b724DADDC921cB
### ETH: 0x6D9045A7Aa129f829C3A6A9D33Bcd0E418c728e2
<p align="right">(<a href="#readme-top">back to top</a>)</p>
